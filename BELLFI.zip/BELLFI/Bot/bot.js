const { Telegraf } = require("telegraf");
const TOKEN = "7454146253:AAFVIBrfP7tKJxtEKWb4OoyJ-y12rBpnY5c";
const bot = new Telegraf(TOKEN);

const web_link = "https://bellfi.vercel.app";
const community_link = process.env.COMMUNITY_LINK||
  "https://t.me/bell_fi";

bot.start((ctx) => {
  const startPayload = ctx.startPayload;
  const urlSent = `${web_link}?ref=${startPayload}`;
  const user = ctx.message.from;
  const userName = user.username ? `@${user.username}` : user.first_name;
  ctx.replyWithMarkdown(`*Hey, ${userName}! Welcome to BELL Fi!*
Tap on the bell and see your reward rise.

*BELL Fi * $ is a  ring-to-earn Web3 game. Bell will be the main utility token in the Bell Fi  Web applications.

Where are your buddy?
Get them  into the game.
More buddies, more rewards.`, {
      reply_markup: {
          inline_keyboard: [
            [{ text: "👋 Start now!", web_app: { url: urlSent } }],
            [{ text: "Join Community", url: community_link }]

          ],
          in: true
      },
  });
});



bot.launch();
