import React, { useState, useEffect, useRef, useContext } from 'react';
import styled, { keyframes } from 'styled-components';
import './App.css';
import coinsmall from '../src/images/coinsmall.webp';
import tapmecoin from '../src/images/tapme1.png';
import bronze from '../src/images/bronz.png';
import { MdOutlineKeyboardArrowRight } from 'react-icons/md';
import { db } from './firebase';
import { collection, addDoc, getDocs, updateDoc } from './firebase';
import Animate from './Components/Animate';
import Spinner from './Components/Spinner';
import Levels from './Components/Levels';
import flash from '../src/images/flash.webp';
import { EnergyContext } from './context/EnergyContext';
import Loading from './pages/loading';


const slideUp = keyframes`
  0% {
    opacity: 1;
    transform: translateY(0);
  }
  100% {
    opacity: 0;
    transform: translateY(-350px);
  }
`;

const SlideUpText = styled.div`
  position: absolute;
  animation: ${slideUp} 3s ease-out;
  font-size: 2.1em;
  color: #ffffffa6;
  font-weight: 600;
  left: ${({ x }) => x}px;
  top: ${({ y }) => y}px;
  pointer-events: none;
`;

const Container = styled.div`
  position: relative;
  display: inline-block;
  text-align: center;
  width: 100%;
  height: 100%;
`;

const EnergyFill = styled.div`
  background-color: #e39725;
  height: 12px;
  border-radius: 6px;
  width: ${({ percentage }) => percentage}%;
`;

function App() {
  const { energy, setEnergy, displayEnergy, setDisplayEnergy, idme, setIdme, count, setCount } = useContext(EnergyContext);
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const imageRef = useRef(null);
  const [clicks, setClicks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showLevels, setShowLevels] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const splashShown = localStorage.getItem('splashShown');

    if (!splashShown) {
      // Show splash screen for 7 seconds
      setTimeout(() => {
        setShowSplash(false);
        localStorage.setItem('splashShown', 'true');
      }, 7000);
    } else {
      setShowSplash(false);
    }
  }, []);

  const levelsAction = () => {
    setShowLevels(true);
    document.getElementById("footermain").style.zIndex = "50";
  };

  const handleClick = (e) => {
    if (energy > 0) {
      const { offsetX, offsetY, target } = e.nativeEvent;
      const { clientWidth, clientHeight } = target;

      const horizontalMidpoint = clientWidth / 2;
      const verticalMidpoint = clientHeight / 2;

      const animationClass =
        offsetX < horizontalMidpoint
          ? "wobble-left"
          : offsetX > horizontalMidpoint
          ? "wobble-right"
          : offsetY < verticalMidpoint
          ? "wobble-top"
          : "wobble-bottom";

      imageRef.current.classList.remove(
        "wobble-top",
        "wobble-bottom",
        "wobble-left",
        "wobble-right"
      );

      imageRef.current.classList.add(animationClass);

      setTimeout(() => {
        imageRef.current.classList.remove(animationClass);
      }, 500);

      const rect = e.target.getBoundingClientRect();
      const newClick = {
        id: Date.now(),
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };

      const updatedCount = count + 2;
      const updatedEnergy = energy - 2;

      setClicks((prevClicks) => [...prevClicks, newClick]);
      setCount(updatedCount);
      setEnergy(updatedEnergy);
      setDisplayEnergy(updatedEnergy);

      updateUserStatsInFirestore(idme, updatedCount, updatedEnergy);

      setTimeout(() => {
        setClicks((prevClicks) =>
          prevClicks.filter((click) => click.id !== newClick.id)
        );
      }, 1000);
    }
  };

  useEffect(() => {
    const telegramName = window.Telegram.WebApp.initDataUnsafe?.user?.first_name;
    const telegramLastName = window.Telegram.WebApp.initDataUnsafe?.user?.last_name;
    const telegramUsername = window.Telegram.WebApp.initDataUnsafe?.user?.username;
    const telegramUserid = window.Telegram.WebApp.initDataUnsafe?.user?.id;

    if (telegramName) {
      setName(telegramName + " " + telegramLastName);
    }

    if (telegramUsername) {
      setUsername(telegramUsername);
    }
    if (telegramUserid) {
      setIdme(telegramUserid);
    }

    if (telegramUsername && telegramUserid) {
      saveRefereeIdToFirestore();
    }

    if (telegramUserid) {
      fetchUserStatsFromFirestore(telegramUserid)
        .then((userStats) => {
          if (isNaN(userStats.count)) {
            setCount(0);
            updateUserStatsInFirestore(telegramUserid, 0, 500);
          } else {
            setCount(userStats.count);
            setEnergy(userStats.energy);
            setDisplayEnergy(userStats.energy);
          }
          setLoading(false);
        })
        .catch(() => {
          setCount(0);
          setEnergy(500);
          setLoading(false);
        });
    }
  }, []);

  const saveRefereeIdToFirestore = async () => {
    const telegramUsername = window.Telegram.WebApp.initDataUnsafe?.user?.username;
    const telegramUserid = window.Telegram.WebApp.initDataUnsafe?.user?.id;
    const telegramName = window.Telegram.WebApp.initDataUnsafe?.user?.first_name;
    const telegramLastName = window.Telegram.WebApp.initDataUnsafe?.user?.last_name;

    const fullName = telegramName + " " + telegramLastName;

    const queryParams = new URLSearchParams(window.location.search);
    let refereeId = queryParams.get("ref");
    if (refereeId) {
      refereeId = refereeId.replace(/\D/g, "");
    }

    if (telegramUsername && telegramUserid) {
      await storeUserData(
        fullName,
        telegramUsername,
        telegramUserid,
        refereeId
      );
    }
  };

  const storeUserData = async (fullname, username, userid, refereeId) => {
    try {
      const userRef = collection(db, "telegramUsers");
      const querySnapshot = await getDocs(userRef);
      let userExists = false;

      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          userExists = true;
        }
      });

      if (!userExists) {
        await addDoc(userRef, {
          fullname: fullname,
          username: username,
          userId: userid,
          count: 0,
          energy: 500,
          refereeId: refereeId || null,
          timestamp: new Date(),
        });
      }
    } catch (e) {
      console.error("Error adding document: ", e);
    }
  };
  const overflow = 100
document.body.style.overflowY = 'hidden'
document.body.style.marginTop = `${overflow}px`
document.body.style.height = window.innerHeight + overflow + "px"
document.body.style.paddingBottom = `${overflow}px`
window.scrollTo(0, overflow);

  const updateUserStatsInFirestore = async (userid, newCount, newEnergy) => {
    try {
      const userRef = collection(db, "telegramUsers");
      const querySnapshot = await getDocs(userRef);

      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          const docRef = doc.ref;
          updateDoc(docRef, { count: newCount, energy: newEnergy });
        }
      });
    } catch (e) {
      console.error("Error updating document: ", e);
    }
  };

  const fetchUserStatsFromFirestore = async (userid) => {
    try {
      const userRef = collection(db, "telegramUsers");
      const querySnapshot = await getDocs(userRef);
      let userStats = { count: 0, energy: 500 };

      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          userStats = { count: doc.data().count, energy: doc.data().energy };
        }
      });

      return userStats;
    } catch (e) {
      console.error("Error fetching user stats: ", e);
      return { count: 0, energy: 500 };
    }
  };

  if (showSplash) {
    return <SplashScreen />;
  }

  return (
    <div className="App">
      {loading && <Loading />}
      <header className="App-header">
        <Container>
          <div className="displaycenter">
            <h1>{count}</h1>
            <img
              src={tapmecoin}
              className="tapmecoin"
              alt="logo"
              onClick={handleClick}
              ref={imageRef}
            />
          </div>
          <div className="energy-container">
            <div className="energy">
              <div className="energy-fill">
                <EnergyFill percentage={displayEnergy / 5} />
              </div>
            </div>
          </div>
          <div className="flash-container">
            {clicks.map((click) => (
              <SlideUpText key={click.id} x={click.x} y={click.y}>
                +2
              </SlideUpText>
            ))}
          </div>
          <div className="coinflash-container">
            <img
              src={flash}
              className="flash-coin"
              alt="coinflash"
              id="coinflash"
            />
          </div>
        </Container>
      </header>
      <footer className="footer" id="footermain">
        <div className="footer-content">
          <div className="profile">
            <div className="profile-image">
              <img src={bronze} alt="Bronze" />
            </div>
            <div className="profile-details">
              <h3>{username}</h3>
              <p>{name}</p>
            </div>
          </div>
          <div className="levels" onClick={levelsAction}>
            <MdOutlineKeyboardArrowRight size={24} />
          </div>
        </div>
      </footer>
      <Animate show={showLevels}>
        <Levels setShowLevels={setShowLevels} />
      </Animate>
    </div>
  );
}

export default App;
