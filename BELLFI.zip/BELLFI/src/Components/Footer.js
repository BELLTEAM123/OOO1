import React from "react";
import ref from "../images/friends.png";
import boost from "../images/boost.webp";
import tasks from "../images/earn.png";
import stats from "../images/matrices.png";
import coinsmall from "../images/mine.png";
import "./globals.css";
import "./style.css";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <div className="footer-container">
      <NavLink
        to="/ref"
        className={({ isActive }) => {
          return isActive
            ? "footer-item active"
            : "footer-item";
        }}
      >
        <img src={ref} className="footer-icon" alt="ref" />
        <span className="footer-label">Friends</span>
      </NavLink>
      <NavLink
        to="/tasks"
        className={({ isActive }) => {
          return isActive
            ? "footer-item active"
            : "footer-item";
        }}
      >
        <img src={tasks} className="footer-icon" alt="tasks" />
        <span className="footer-label">Earn</span>
      </NavLink>
      <NavLink
        to="/"
        className={({ isActive }) => {
          return isActive
            ? "footer-item active"
            : "footer-item";
        }}
      >
        <img src={coinsmall} className="footer-icon" alt="tap" />
        <span className="footer-label">Mine</span>
      </NavLink>
      <NavLink
        to="/stats"
        className={({ isActive }) => {
          return isActive
            ? "footer-item active"
            : "footer-item";
        }}
      >
        <img src={stats} className="footer-icon" alt="stats" />
        <span className="footer-label">Matrices</span>
      </NavLink>
    </div>
  );
};

export default Footer;
