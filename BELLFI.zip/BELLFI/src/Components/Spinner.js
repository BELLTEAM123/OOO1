// src/Components/SplashScreen.js

import React from 'react';
import styled from 'styled-components';
import splashImage from '../images/preloader.png'; // Replace with your splash image path

const SplashScreenContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100vw;
  height: 120vh;
  background: url(${splashImage}) no-repeat center center;
  background-size: cover;
  overflow:hidden;
`;

function Spinner() {
  return (
    <SplashScreenContainer>
      {/* Add any additional content you want to display on the splash screen */}
    </SplashScreenContainer>
  );
}

export default Spinner;
