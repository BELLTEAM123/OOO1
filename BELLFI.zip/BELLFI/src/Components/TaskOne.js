import coinsmall from "../images/coinsmall.webp";
import claim from "../images/claim.PNG";
import { useContext, useEffect, useState } from "react";
import { db } from "../firebase";
import {
  collection,
  getDoc,
  getDocs,
  updateDoc,
  doc,
  where, 
  query,
  setDoc,
} from "../firebase";
import { EnergyContext } from "../context/EnergyContext";

const TaskOne = ({ showModal, setShowModal }) => {
  const { count, setCount } = useContext(EnergyContext);
  const [idme, setIdme] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [showCheckButton, setShowCheckButton] = useState(false);
  const [showDoneButton, setShowDoneButton] = useState(false);
  const [message, setMessage] = useState("");
  const [showTaskButton, setShowTaskButton] = useState(true);
  const [counter, setCounter] = useState(null);
  const [intervalId, setIntervalId] = useState(null);
  const taskID = "task_3100";
  const [taskCompleted, setTaskCompleted] = useState(false);
  const [openComplete, setOpenComplete] = useState(false);

  const [isMissionButtonDisabled, setIsMissionButtonDisabled] = useState(true);

  useEffect(() => {
    const handleBackButtonClick = () => {
      setShowModal(false);
      document.getElementById("footermain").style.zIndex = "";
    };
  
    if (showModal) {
      window.Telegram.WebApp.BackButton.show();
      window.Telegram.WebApp.BackButton.onClick(handleBackButtonClick);
    } else {
      window.Telegram.WebApp.BackButton.hide();
      window.Telegram.WebApp.BackButton.offClick(handleBackButtonClick);
    }
  
    return () => {
      window.Telegram.WebApp.BackButton.offClick(handleBackButtonClick);
    };
  }, [showModal, setShowModal]);
  
  useEffect(() => {
    const telegramUserid = window.Telegram.WebApp.initDataUnsafe?.user?.id;

    if (telegramUserid) {
      setIdme(telegramUserid);
    }

    if (telegramUserid) {
      fetchCountFromFirestore(telegramUserid).then((userCount) => {
        setCount(userCount);
      });

      checkTaskCompletion(telegramUserid, taskID).then((completed) => {
        setTaskCompleted(completed);
        if (completed) {
          setMessage("");
          setIsMissionButtonDisabled(false);
        }
      });
    }
  }, []);

  const handleTaskLinkClick = () => {
    window.open("http://t.me/Bell_Fi_channel");

    setTimeout(() => {
      setShowTaskButton(false);
    }, 2000);
    setTimeout(() => {
      setShowCheckButton(true);
    }, 2000);
  };

  const handleVerify = async () => {
    if (intervalId) {
      clearInterval(intervalId);
    }

    const response = await fetch(
      `https://api.telegram.org/bot7390360298:AAFki51t882eThYUb15uRgyhKR8QuZOhZCw/getChatMember?chat_id=-1002226430708&user_id=${idme}`
    );
    const data = await response.json();

    if (data.ok && data.result.status === "member") {
      setIsVerified(true);
      setCounter(15);
      setTimeout(() => {
        setShowDoneButton(true);
      }, 3000);
      setTimeout(() => {
        setShowCheckButton(false);
        setMessage("");
        setIsMissionButtonDisabled(false);
      }, 3000);
    } else {
      setTimeout(() => {
        setMessage(
          "Please join the Telegram channel first before you can claim this task bonus."
        );
      }, 1000);
      setCounter(15);
      const newIntervalId = setInterval(() => {
        setCounter((prevCounter) => {
          if (prevCounter === 1) {
            clearInterval(newIntervalId);
            setShowCheckButton(false);
            setShowTaskButton(true);
            setCounter(null);
          }
          return prevCounter - 1;
        });
      }, 2000);
      setIntervalId(newIntervalId);
    }
  };

  const fetchCountFromFirestore = async (userid) => {
    try {
      const userRef = collection(db, "telegramUsers");
      const querySnapshot = await getDocs(userRef);
      let userCount = 0;
      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          userCount = doc.data().count;
        }
      });
      return userCount;
    } catch (e) {
      console.error("Error fetching document: ", e);
      return 0;
    }
  };

  const updateUserCountInFirestore = async (userid, newCount) => {
    try {
      const userRef = collection(db, "telegramUsers");
      const querySnapshot = await getDocs(userRef);
      let userDocId = null;
      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          userDocId = doc.id;
        }
      });

      if (userDocId) {
        const userDocRef = doc(db, "telegramUsers", userDocId);
        await updateDoc(userDocRef, { count: newCount });
      } else {
        console.error("User document not found.");
      }
    } catch (e) {
      console.error("Error updating user count in Firestore: ", e);
    }
  };

  const finishMission = async () => {
    setShowModal(false);
    setOpenComplete(false);
    document.getElementById("congrat").style.opacity = "1";
    document.getElementById("congrat").style.visibility = "visible";
    setTimeout(() => {
      document.getElementById("congrat").style.opacity = "0";
      document.getElementById("congrat").style.visibility = "invisible";
    }, 2000);

    if (isVerified) {
      const newCount = count + 10000;
      setCount(newCount);
      setMessage("");
      setIsMissionButtonDisabled(true);
      await saveTaskCompletionToFirestore(idme, taskID, true);
      await updateUserCountInFirestore(idme, newCount);

      setTaskCompleted(true);
    } else {
      setMessage("Please verify the task first.");
    }
  };

 
// Define the function to check task completion
const checkTaskCompletion = async (userid, taskId) => {
  try {
    // Ensure userid is a string
    userid = String(userid);

    const taskRef = doc(db, "taskCompletions", userid);
    const taskDoc = await getDoc(taskRef);

    if (taskDoc.exists()) {
      const taskData = taskDoc.data();
      return taskData.completedTasks?.includes(taskId) ?? false;
    } else {
      return false;
    }
  } catch (error) {
    console.error("Error checking task completion: ", error);
    return false;
  }
};

const saveTaskCompletionToFirestore = async (userid, taskId, completed) => {
  try {
    // Ensure userid is a string
    userid = String(userid);

    const taskRef = doc(db, "taskCompletions", userid);
    const taskDoc = await getDoc(taskRef);

    if (taskDoc.exists()) {
      const taskData = taskDoc.data();
      const updatedCompletedTasks = completed
        ? [...(taskData.completedTasks || []), taskId]
        : taskData.completedTasks;

      await updateDoc(taskRef, { completedTasks: updatedCompletedTasks });
    } else {
      await setDoc(taskRef, {
        completedTasks: completed ? [taskId] : []
      });
    }
  } catch (error) {
    console.error("Error saving task completion: ", error);
  }
};

    
  // Define the handleComplete function
  const handleComplete = async (completed) => {
    if (completed) {
      // Handle completion logic, e.g., show a confirmation or update the task status
      await saveTaskCompletionToFirestore(idme, taskID, true);
      setOpenComplete(true);
    }
  };

  return (
    <>
    {showModal ? (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100vh',
          width: '100vw',
          position: 'fixed',
          top: 0,
          left: 0,
          backgroundImage: `url('')`, // Replace with your background image path
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          zIndex: 9999,
          padding: '10px', // Adjusted padding for mobile
        }}
      >
        <div
          style={{
            width: '100%',
            maxWidth: '400px', // Adjusted for mobile screens
            backgroundColor: '#191919',
            borderRadius: '10px',
            padding: '20px', // Internal padding
            position: 'relative',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          }}
        >
          <button
            style={{
              position: 'absolute',
              top: '10px',
              right: '10px',
              color: '#000',
              cursor: 'pointer',
            }}
            onClick={() => setShowModal(false)}
          >
            {/* Your back button icon here */}
          </button>
          <div style={{ display: 'flex', flexDirection: 'column', border: '1px solid #fff', padding: '10px' }}>
          <h1 style={{ fontSize: '20px', fontWeight: 'bold', textAlign:'center' }}>Join Our Socials</h1>
            <p style={{ color: '#fff',textAlign:"center", fontSize: '16px', fontWeight: 'medium', paddingTop: '5px', paddingBottom: '20px' }}>
              Join our social page to get regular updates about this airdrop bot and its great potentials
            </p>
            <p style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold', color: '#49ee49', paddingBottom: '10px' }}>
              {taskCompleted ? "Task is Completed" : ""}
            </p>
            <div style={{ backgroundColor: '#efc26999', borderRadius: '10px', padding: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div>
                  <img src={coinsmall} style={{ width: '50px' }} alt="Coin Icon" />
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                  <span style={{ fontWeight: 'bold' }}>Reward</span>
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    <span style={{ fontWeight: 'medium' }}>10 000</span>
                  </div>
                </div>
              </div>
            </div>
            <h1 style={{ fontSize: '20px', fontWeight: 'bold', paddingTop: '0px', paddingBottom: '10px' }}>Your Tasks</h1>
            <div style={{ backgroundColor: '#efc26999', borderRadius: '10px', padding: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <span style={{ fontWeight: 'bold' }}>Join the Telegram Channel</span>
                {message && (
                  <span style={{ color: '#FFFFFF', fontSize: '12px', paddingRight: '32px' }}>
                    {message}
                  </span>
                )}
              </div>
              <div>
                {!taskCompleted && showTaskButton && (
                  <button
                    onClick={handleTaskLinkClick}
                    style={{
                      display: 'flex',
                      fontWeight: 'medium',
                      backgroundColor: '#fa0',
                      transition: 'background-color 0.3s ease-in',
                      padding: '6px 16px',
                      borderRadius: '8px',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                      color: '#fff',
                    }}
                  >
                    Go
                  </button>
                )}
                {showCheckButton && (
                  <button
                    onClick={handleVerify}
                    style={{
                      display: 'flex',
                      fontWeight: 'medium',
                      backgroundColor: '#fa0',
                      padding: '6px 16px',
                      borderRadius: '8px',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                      color: '#fff',
                    }}
                  >
                    <span> Check</span>
                    <span style={{ color: '#b0b0b0', pointerEvents: 'none', userSelect: 'none' }}>
                      {counter !== null && (
                        <>
                          <span style={{ color: '#fff' }}>ing</span>
                          {` ${counter}s`}
                        </>
                      )}
                    </span>
                  </button>
                )}
                {showDoneButton && (
                  <button
                    id="done"
                    style={{
                      color: '#7cf47c',
                      fontWeight: 'medium',
                      padding: '6px 16px',
                      borderRadius: '8px',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '16px',
                    }}
                  >
                    Done
                  </button>
                )}
              </div>
            </div>
            {taskCompleted ? (
              <button
                style={{
                  marginTop: '20px',
                  width: '100%',
                  padding: '20px 16px',
                  display: 'flex',
                  alignItems: 'center',
                  borderRadius: '12px',
                  justifyContent: 'center',
                  textAlign: 'center',
                  fontSize: '20px',
                  fontWeight: 'medium',
                  color: '#6a6978',
                  backgroundColor: '#f0f0f0',
                }}
              >
                Mission Completed
              </button>
            ) : (
              <button
                onClick={() => handleComplete(true)}
                disabled={isMissionButtonDisabled}
                style={{
                  marginTop: '20px',
                  width: '100%',
                  padding: '20px 16px',
                  display: 'flex',
                  alignItems: 'center',
                  borderRadius: '12px',
                  justifyContent: 'center',
                  textAlign: 'center',
                  fontSize: '20px',
                  fontWeight: 'medium',
                  color: isMissionButtonDisabled ? '#6a6978' : '#f4f4f4',
                  backgroundColor: isMissionButtonDisabled ? '#f0f0f0' : '#fa0',
                }}
              >
                Finish Mission
              </button>
            )}
          </div>
          {openComplete && (
            <div
              style={{
                visibility: openComplete ? 'visible' : 'hidden',
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0,
                height: '76vh',
                backgroundColor: '#1e2340f7',
                zIndex: 100,
                borderTopLeftRadius: '20px',
                borderTopRightRadius: '20px',
                display: 'flex',
                justifyContent: 'center',
                padding: '20px 16px',
              }}
            >
              <div style={{ width: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', paddingTop: '40px', paddingBottom: '20px' }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div
                    style={{
                      width: '120px',
                      height: '120px',
                      borderRadius: '14px',
                      backgroundColor: '#252e57',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <img alt="claim" src={claim} />
                  </div>
                  <h3 style={{ fontWeight: 'bold', fontSize: '28px', paddingTop: '16px', paddingBottom: '16px' }}>
                    Congratulations
                  </h3>
                  <p style={{ paddingBottom: '20px', color: '#9a96a6', fontSize: '16px' }}>
                    You have successfully completed the mission
                  </p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div>
                      <img src={coinsmall} style={{ width: '25px' }} alt="Coin Icon" />
                    </div>
                    <div style={{ fontWeight: 'bold', fontSize: '20px' }}>10000</div>
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center', paddingBottom: '30px' }}>
                  <button
                    onClick={finishMission}
                    style={{
                      background: 'linear-gradient(to bottom, #ffba4c, #aa6900)',
                      width: '100%',
                      padding: '20px 16px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      textAlign: 'center',
                      borderRadius: '12px',
                      fontWeight: 'bold',
                      fontSize: '22px',
                      color: '#000',
                    }}
                  >
                    Claim
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    ) : null}
  </>
  
  
  
  );
};

export default TaskOne;
