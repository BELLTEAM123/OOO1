import React, { createContext, useState, useEffect } from "react";
import { collection, query, where, getDocs, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

const EnergyContext = createContext();

const EnergyProvider = ({ children }) => {
  const [energy, setEnergy] = useState(null);
  const [displayEnergy, setDisplayEnergy] = useState(null);
  const [idme, setIdme] = useState("");
  const [count, setCount] = useState(0);
  const [level, setLevel] = useState("level1");
  const [isClicking, setIsClicking] = useState(false);

  const calculateMaxEnergy = (level) => {
    const levelNumber = parseInt(level.replace("level", ""));
    return 500 + (levelNumber - 1) * 200;
  };

  const fetchUserData = async () => {
    if (idme) {
      try {
        const userRef = collection(db, "telegramUsers");
        const q = query(userRef, where("userId", "==", idme));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
          const userDoc = querySnapshot.docs[0];
          const userData = userDoc.data();
          const storedEnergy = userData.energy;
          const lastUpdated = userData.lastInteraction.toDate();

          const now = Date.now();
          const lastUpdatedTime = lastUpdated.getTime();
          const elapsed = now - lastUpdatedTime;
          const elapsedSeconds = Math.floor(elapsed / 1000);
          const energyRecovered = Math.floor(elapsedSeconds / 2); // Assuming 1 energy per 2 seconds

          const maxEnergy = calculateMaxEnergy(userData.level);
          const newEnergy = Math.min(storedEnergy + energyRecovered, maxEnergy);

          setEnergy(newEnergy);
          setDisplayEnergy(newEnergy);
          setLevel(userData.level);

          await updateDoc(userDoc.ref, { energy: newEnergy, lastInteraction: new Date() });
        }
      } catch (error) {
        console.error("Error fetching user data from Firestore:", error);
      }
    }
  };

  const recoverEnergy = async () => {
   
  };

  useEffect(() => {
    fetchUserData();
  }, [idme]);

  useEffect(() => {
    const interval = setInterval(recoverEnergy, 1000);

    return () => clearInterval(interval);
  }, [idme, level, isClicking, energy]);

  return (
    <EnergyContext.Provider
      value={{
        energy,
        setEnergy,
        displayEnergy,
        setDisplayEnergy,
        idme,
        setIdme,
        count,
        setCount,
        level,
        setLevel,
        isClicking,
        setIsClicking,
      }}
    >
      {children}
    </EnergyContext.Provider>
  );
};

export { EnergyContext, EnergyProvider };
