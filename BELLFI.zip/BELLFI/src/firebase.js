// src/firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { collection,
  getDoc,
  getDocs,
  updateDoc,
  doc,query, where,
  setDoc,addDoc , querySnapshot } from "firebase/firestore";
  
  const firebaseConfig = {
    apiKey: "AIzaSyCfK3JsEbM704iZqLjJ_JbGbRPmXohiBdM",
    authDomain: "bell-fi.firebaseapp.com",
    projectId: "bell-fi",
    storageBucket: "bell-fi.appspot.com",
    messagingSenderId: "582992793220",
    appId: "1:582992793220:web:a1c9985dc8596bf5a8fcd1",
    measurementId: "G-8BSTV8HHSK"
  };
  

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
console.log("Firebase initialized:", app);
console.log("Firestore initialized:", db);

export { db ,collection,  getDoc, getDocs,  updateDoc, query, where, doc,setDoc,addDoc };
