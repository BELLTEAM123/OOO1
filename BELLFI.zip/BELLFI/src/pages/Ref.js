import React, { useEffect, useState } from "react";
import Animate from "../Components/Animate";
import { Outlet } from "react-router-dom";
import { db } from "../firebase";
import { collection, getDocs } from "firebase/firestore";
import bronze from "../images/bronz.png";
import coinsmall from "../images/coinsmall.webp";

const Ref = () => {
  const [count, setCount] = useState(0);
  const [username, setUsername] = useState(null);
  const [idme, setIdme] = useState(null);
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [copied, setCopied] = useState(false);

  const formattedCount = new Intl.NumberFormat().format(count).replace(/,/g, " ");

  useEffect(() => {
    console.log("Component mounted");

    const telegramUsername = window.Telegram?.WebApp?.initDataUnsafe?.user?.username ?? null;
    const telegramUserid = window.Telegram?.WebApp?.initDataUnsafe?.user?.id ?? null;

    console.log("Telegram Username:", telegramUsername);
    console.log("Telegram User ID:", telegramUserid);

    setUsername(telegramUsername);
    setIdme(telegramUserid);

    fetchAllUsers();
  }, []);

  useEffect(() => {
    console.log("Users:", users);
    console.log("ID Me:", idme);

    if (users.length > 0 && idme) {
      const updatedFilteredUsers = users.filter(user => user.refereeId?.toString() === idme.toString());

      console.log("Filtered Users:", updatedFilteredUsers);
      setFilteredUsers(updatedFilteredUsers);
    }
  }, [users, idme]);

  const fetchAllUsers = async () => {
    console.log("Fetching all users");

    try {
      const userRef = collection(db, "telegramUsers");
      const querySnapshot = await getDocs(userRef);

      console.log("Query Snapshot:", querySnapshot);

      const uniqueUsers = new Map();

      querySnapshot.forEach((doc) => {
        const data = doc.data();
        const username = data.username ?? null;
        const fullname = data.fullname ?? null;
        const refereeId = data.refereeId ?? null;
        const count = data.count ?? 0;
        const userId = data.userId ?? null;

        console.log("Document Data:", data);

        const key = `${userId}-${refereeId}`;

        if (!uniqueUsers.has(key)) {
          uniqueUsers.set(key, { username, fullname, refereeId, count, userId });
        }
      });

      const uniqueUserList = Array.from(uniqueUsers.values());
      console.log("Unique Users:", uniqueUserList);

      setUsers(uniqueUserList);

      const telegramUserid = window.Telegram?.WebApp?.initDataUnsafe?.user?.id ?? null;
      const currentUserId = telegramUserid?.toString() ?? null;

      console.log("Current User ID:", currentUserId);

      const totalReferrals = uniqueUserList.reduce((acc, user) => {
        const userRefereeId = user.refereeId?.toString() ?? null;
        if (userRefereeId === currentUserId) {
          return acc + 1;
        }
        return acc;
      }, 0);

      console.log("Total Referrals for Current User:", totalReferrals);

      setCount(totalReferrals);
    } catch (error) {
      console.error("Error fetching users: ", error);
    }
  };

  const copyToClipboard = () => {
    const telegramUserid = window.Telegram?.WebApp?.initDataUnsafe?.user?.id ?? null;

    if (telegramUserid) {
      setIdme(telegramUserid);
    } else {
      console.warn("Telegram User ID is undefined during copy");
    }

    const reflink = `http://t.me/Bellfigame_bot?start=r${telegramUserid}`;

    console.log("Referral Link:", reflink);

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(reflink).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 10000);
      }).catch(err => {
        console.error('Failed to copy text: ', err);
      });
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = reflink;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
        setTimeout(() => setCopied(false), 10000);
      } catch (err) {
        console.error('Failed to copy', err);
      }
      document.body.removeChild(textArea);
    }
  };

  return (
    <>
      <Animate>
        <div className="w-full justify-center flex-col space-y-3 px-5">
          <div className="flex space-y-0 flex-col justify-center items-center">
            <h1 className="text-[#fff] -mb-2 text-[42px] font-semibold">
              {formattedCount ? formattedCount : "0"} Users
            </h1>
            <span className="text-[#6ed86e] font-semibold text-[16px]">
              {/* + 0 */}
            </span>
          </div>

          <div className="w-full bg-cards rounded-[12px] px-3 py-4 flex flex-col">
            <span className="w-full flex justify-between items-center pb-2">
              <h2 className="text-[18px] font-semibold">My invite link:</h2>
              <span
                onClick={copyToClipboard}
                className="bg-gradient-to-b from-[#fa0] to-[#fa0] font-medium py-[6px] px-4 rounded-[12px] flex items-center justify-center text-[16px]"
              >
                {copied ? <span>Copied!</span> : <span>Copy</span>}
              </span>
            </span>

            <div className="text-[#9a96a6] text-[13px]">
              http://t.me/Bellfigame_bot?start=r{idme}
            </div>
          </div>
          <div className="bg-borders w-full px-5 h-[1px] !mt-6"></div>
          <div className="bg-[#efc26999] blur-[50px] absolute rotate-[35deg] w-[400px] h-[160px] -left-40 rounded-full"></div>
          <div className="w-full flex flex-col">
            <h3 className="text-[22px] font-semibold pb-[16px]">My Referrals:</h3>

            <div className="w-full flex flex-col space-y-3 h-[400px] overflow-y-auto pb-[100px]">
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user, index) => (
                  <div
                    key={index}
                    className="bg-cards rounded-[10px] p-[14px] flex flex-wrap justify-between items-center"
                  >
                    <div className="flex flex-1 flex-col space-y-1">
                      <div className="text-[#fff] pl-1 text-[16px] font-semibold">
                        {user.fullname}
                      </div>

                      <div className="flex items-center space-x-1 text-[14px] text-[#e5e5e5]">
                        <div className="">
                          <img src={bronze} alt="bronze" className="w-[18px]" />
                        </div>
                        <span className="font-medium text-[#9a96a6]">
                          Bronze
                        </span>
                        <span className="bg-[#bdbdbd] w-[1px] h-[13px] mx-2"></span>

                        <span className="w-[20px]">
                          <img
                            src={coinsmall}
                            className="w-full"
                            alt="coin"
                          />
                        </span>
                        <span className="font-normal text-[#ffffff] text-[15px]">
                          {user.count}
                        </span>
                      </div>
                    </div>

                    <div className="text-[#ffce68] font-semibold text-[14px]">
                      +0
                    </div>
                    <div className="flex w-full mt-2 p-[4px] items-center bg-energybar rounded-[10px] border-[1px] border-borders">
                      <div className="h-[10px] rounded-[8px] bg-btn w-[.5%]"></div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="w-full text-center text-[16px] py-5">
                  No Referrals
                </p>
              )}
            </div>
          </div>
        </div>
      </Animate>
      <Outlet />
    </>
  );
};

export default Ref;
