import React, { useState, useEffect, useRef } from "react";
import styled, { keyframes } from "styled-components";
import { useLocation } from "react-router-dom"; // Import useLocation from react-router-dom
import "../App.css";
import coinsmall from "../images/coinsmall.webp";
import tapmecoin from "../images/bronz.png";
import bronze from "../images/bronz.png";
import silver from "../images/silver.png";
import gold from "../images/gold.png";
import platinum from "../images/platinum.png";
import diamond from "../images/diamond.png";
import { MdOutlineKeyboardArrowRight, MdOutlineKeyboardArrowLeft } from "react-icons/md";
import { db } from "../firebase";
import { collection, addDoc, getDocs, doc, updateDoc, query, where } from "firebase/firestore";
import Animate from "../Components/Animate";
import flash from "../images/flash.webp";

const slideUp = keyframes`
  0% {
    opacity: 1;
    transform: translateY(0);
  }
  100% {
    opacity: 0;
    transform: translateY(-350px);
  }
`;

const SlideUpText = styled.div`
  position: absolute;
  animation: ${slideUp} 3s ease-out;
  font-size: 2.1em;
  color: #ffffffa6;
  font-weight: 600;
  left: ${({ x }) => x}px;
  top: ${({ y }) => y}px;
  pointer-events: none;
`;

const Container = styled.div`
  position: relative;
  display: inline-block;
  text-align: center;
  width: 100%;
  height: 100%;
`;

const EnergyFill = styled.div`
  background-color: #e39725;
  height: 12px;
  border-radius: 6px;
  width: ${({ percentage }) => percentage}%;
`;

const TapHome = () => {
  const [energy, setEnergy] = useState(0);
  const [displayEnergy, setDisplayEnergy] = useState(0);
  const [idme, setIdme] = useState("");
  const [count, setCount] = useState(0);
  const [level, setLevel] = useState("level1");
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const imageRef = useRef(null);
  const [clicks, setClicks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showLevels, setShowLevels] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isClicking, setIsClicking] = useState(false);
  const location = useLocation(); // Hook to get the current location

  const levels = {
    level1: { name: 'Level 1', minCount: 0, nextLevel: 'level2', claimCount: 5000 },
    level2: { name: 'Level 2', minCount: 5000, nextLevel: 'level3', claimCount: 25000 },
    level3: { name: 'Level 3', minCount: 25000, nextLevel: 'level4', claimCount: 100000 },
    level4: { name: 'Level 4', minCount: 100000, nextLevel: 'level5', claimCount: 1000000 },
    level5: { name: 'Level 5', minCount: 1000000, nextLevel: 'level6', claimCount: 10000000 },
    level6: { name: 'Level 6', minCount: 10000000, nextLevel: 'level7', claimCount: 50000000 },
    level7: { name: 'Level 7', minCount: 50000000, nextLevel: 'level8', claimCount: 100000000 },
    level8: { name: 'Level 8', minCount: 100000000, nextLevel: null, claimCount: null },
  };

  useEffect(() => {
    const initializeUserData = async () => {
      try {
        const telegramName = window.Telegram.WebApp.initDataUnsafe?.user?.first_name;
        const telegramLastName = window.Telegram.WebApp.initDataUnsafe?.user?.last_name;
        const telegramUsername = window.Telegram.WebApp.initDataUnsafe?.user?.username;
        const telegramUserid = window.Telegram.WebApp.initDataUnsafe?.user?.id;


        const fetchUserData = async () => {
          if (telegramUserid) {
            // Load user stats from local storage
            const localUserStats = JSON.parse(localStorage.getItem('userStatsTasks'));
            if (localUserStats && localUserStats.userid === telegramUserid) {
              setCount(localUserStats.count);
              setLevel(localUserStats.level || 'level1');
              setLoading(false); // Data loaded from local storage
            }
    
            // Fetch user stats from Firestore
            const userRef = collection(db, 'telegramUsers');
            const q = query(userRef, where('userId', '==', telegramUserid));
            const querySnapshot = await getDocs(q);
            querySnapshot.forEach((doc) => {
              const data = doc.data();
              setCount(data.count);
              setLevel(data.level || 'level1');
    
              // Save the latest user stats to local storage
              localStorage.setItem('userStatsTasks', JSON.stringify({
                userid: telegramUserid,
                count: data.count,
                level: data.level
              }));
            });
    
            setLoading(false); // Data loaded from Firestore
          }
        };

        if (telegramName) {
          setName(telegramName + " " + telegramLastName);
        }

        if (telegramUsername) {
          setUsername(telegramUsername);
        }
        if (telegramUserid) {
          setIdme(telegramUserid);
          fetchUserData();
          const localUserStats = JSON.parse(localStorage.getItem('userStats'));
          const currentTime = new Date().getTime();
          if (localUserStats && localUserStats.userid === telegramUserid) {
            const elapsedTime = currentTime - localUserStats.lastUpdate;
            const energyIncrement = Math.floor(elapsedTime / 1000) * (parseInt(localUserStats.level.replace("level", "")) + 1);
            const maxEnergy = 500 + (parseInt(localUserStats.level.replace("level", "")) - 1) * 200;
            const updatedEnergy = Math.min(localUserStats.energy + energyIncrement, maxEnergy);

            setCount(localUserStats.count);
            setEnergy(updatedEnergy);
            setDisplayEnergy(updatedEnergy);
            setLevel(localUserStats.level);
            setLoading(false);
            fetchUserData();


          } else {
            const userStats = await fetchUserStatsFromFirestore(telegramUserid);
            if (userStats) {
              const maxEnergy = 500 + (parseInt(userStats.level.replace("level", "")) - 1) * 200;
              const updatedEnergy = Math.min(userStats.energy, maxEnergy);

              setCount(userStats.count);
              setEnergy(updatedEnergy);
              setDisplayEnergy(updatedEnergy);
              setLevel(userStats.level);
               
              localStorage.setItem('userStats', JSON.stringify({
                userid: telegramUserid,
                count: userStats.count,
                energy: updatedEnergy,
                level: userStats.level,
                lastUpdate: currentTime
              }));
            } else {
              setCount(0);
              setEnergy(500);
              setDisplayEnergy(500);
              updateUserStatsInFirestore(telegramUserid, 0, 500, "level1");
            }
          }
          setLoading(false);
        }

        await saveRefereeIdToFirestore();
      } catch (error) {
        console.error("Error initializing user data:", error);
        setLoading(false);
      }
    };

    initializeUserData();
  }, [location]); // Re-run the effect when the location changes

  useEffect(() => {
    const getRegenerationRate = () => {
      const currentLevel = parseInt(level.replace("level", ""));
      return currentLevel + 1;
    };

    const maxEnergy = 500 + (parseInt(level.replace("level", "")) - 1) * 200;
    const interval = setInterval(() => {
      setEnergy((prevEnergy) => {
        const newEnergy = Math.min(prevEnergy + getRegenerationRate(), maxEnergy);
        setDisplayEnergy(newEnergy);

        const localUserStats = JSON.parse(localStorage.getItem('userStats'));
        if (localUserStats && localUserStats.userid === idme) {
          localUserStats.energy = newEnergy;
          localUserStats.count = count;
          localUserStats.level = level;
          localUserStats.lastUpdate = new Date().getTime();
          localStorage.setItem('userStats', JSON.stringify(localUserStats));
        }

        return newEnergy;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [idme, count, level]);

  const saveRefereeIdToFirestore = async () => {
    try {
      const telegramUsername = window.Telegram.WebApp.initDataUnsafe?.user?.username;
      const telegramUserid = window.Telegram.WebApp.initDataUnsafe?.user?.id;
      const telegramName = window.Telegram.WebApp.initDataUnsafe?.user?.first_name;
      const telegramLastName = window.Telegram.WebApp.initDataUnsafe?.user?.last_name;

      const fullName = telegramName + " " + telegramLastName;

      const queryParams = new URLSearchParams(window.location.search);
      let refereeId = queryParams.get("ref");
      if (refereeId) {
        refereeId = refereeId.replace(/\D/g, "");
      }

      await storeUserData(fullName, telegramUsername, telegramUserid, refereeId);
    } catch (error) {
      console.error("Error saving referee ID:", error);
    }
  };

  const storeUserData = async (fullname, username, userid, refereeId) => {
    try {
      fullname = fullname ?? null;
      username = username ?? null;
      userid = userid ?? null;
      refereeId = refereeId ?? null;
      const userRef = collection(db, "telegramUsers");
      const querySnapshot = await getDocs(userRef);
      let userExists = false;

      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          userExists = true;
        }
      });

      if (!userExists) {
        await addDoc(userRef, {
          fullname: fullname,
          username: username,
          userId: userid,
          count: 0,
          energy: 500,
          level: 'level1',
          refereeId: refereeId || null,
          timestamp: new Date(),
        });
      }
    } catch (e) {
      console.error("Error adding document: ", e);
    }
  };

  const fetchUserStatsFromFirestore = async (userid) => {
    try {
      const userRef = collection(db, "telegramUsers");
      const q = query(userRef, where("userId", "==", userid));
      const querySnapshot = await getDocs(q);
      let userStats = null;
      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          userStats = {
            count: doc.data().count,
            energy: doc.data().energy,
            level: doc.data().level || 'level1'
          };
        }
      });
      return userStats;
    } catch (e) {
      console.error("Error fetching document: ", e);
      return null;
    }
  };

  const updateUserStatsInFirestore = async (userid, newCount, newEnergy, newLevel) => {
    if (newCount === 0) {
      console.log("Count is zero, not updating Firestore.");
      return;
    }

    try {
      const userRef = collection(db, "telegramUsers");
      const q = query(userRef, where("userId", "==", userid));
      const querySnapshot = await getDocs(q);
      let userDocId = null;
      querySnapshot.forEach((doc) => {
        if (doc.data().userId === userid) {
          userDocId = doc.id;
        }
      });

      if (userDocId) {
        const userDocRef = doc(db, "telegramUsers", userDocId);
        await updateDoc(userDocRef, { count: newCount, energy: newEnergy, level: newLevel });
        console.log(`Updated user stats: count=${newCount}, energy=${newEnergy}, level=${newLevel}`);
      } else {
        console.error("User document not found.");
      }
    } catch (e) {
      console.error("Error updating user stats in Firestore: ", e);
    }
  };

  const handleClick = (e) => {
    if (energy > 0) {
      setIsClicking(true);

      if (window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }

      const { offsetX, offsetY, target } = e.nativeEvent;
      const { clientWidth, clientHeight } = target;

      const horizontalMidpoint = clientWidth / 2;
      const verticalMidpoint = clientHeight / 2;

      const animationClass =
        offsetX < horizontalMidpoint
          ? "wobble-left"
          : offsetX > horizontalMidpoint
          ? "wobble-right"
          : offsetY < verticalMidpoint
            ? "wobble-top"
            : "wobble-bottom";

      imageRef.current.classList.remove(
        "wobble-top",
        "wobble-bottom",
        "wobble-left",
        "wobble-right"
      );

      imageRef.current.classList.add(animationClass);

      setTimeout(() => {
        imageRef.current.classList.remove(animationClass);
      }, 500);

      const rect = e.target.getBoundingClientRect();
      const newClick = {
        id: Date.now(),
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };

      const decrementValue = parseInt(level.slice(-1)) + 1;
      const updatedCount = count + decrementValue;
      const updatedEnergy = Math.max(energy - decrementValue, 0);

      console.log(`Before update: energy=${energy}, displayEnergy=${displayEnergy}, count=${count}`);

      setClicks((prevClicks) => [...prevClicks, newClick]);
      setCount(updatedCount);
      setEnergy(updatedEnergy);
      setDisplayEnergy(updatedEnergy);

      updateUserStatsInFirestore(idme, updatedCount, updatedEnergy, level);

      console.log(`Click event: updatedCount=${updatedCount}, updatedEnergy=${updatedEnergy}`);
      console.log(`After update: energy=${updatedEnergy}, displayEnergy=${updatedEnergy}, count=${updatedCount}`);

      const localUserStats = JSON.parse(localStorage.getItem('userStats'));
      if (localUserStats && localUserStats.userid === idme) {
        localUserStats.energy = updatedEnergy;
        localUserStats.count = updatedCount;
        localUserStats.level = level;
        localUserStats.lastUpdate = new Date().getTime();
        localStorage.setItem('userStats', JSON.stringify(localUserStats));
      }

      setTimeout(() => {
        setClicks((prevClicks) =>
          prevClicks.filter((click) => click.id !== newClick.id)
        );
        setIsClicking(false);
      }, 1000);
    }
  };

  const levelsAction = () => {
    setShowLevels(true);
    document.getElementById("footermain").style.zIndex = "50";
  };

  const overflow = 100;
  document.body.style.overflowY = 'hidden';
  document.body.style.marginTop = `${overflow}px`;
  document.body.style.height = `${window.innerHeight + overflow}px`;
  document.body.style.paddingBottom = `${overflow}px`;
  window.scrollTo(0, overflow);

  const formattedCount = new Intl.NumberFormat().format(count).replace(/,/g, " ");
  const currentLevel = levels[level];
  const nextLevel = currentLevel.nextLevel ? levels[currentLevel.nextLevel] : null;
  const progress = nextLevel ? ((count - currentLevel.minCount) / (nextLevel.minCount - currentLevel.minCount)) * 100 : 100;

  const maxEnergy = 500 + (parseInt(level.replace("level", "")) - 1) * 200;

  if (loading) {
    return (
      <div className="loading-container">
        <h1>

        </h1>
      </div>
    );
  }

  return (
    <>
      <Animate>
        <div className="flex space-x-[2px] justify-center items-center">
          <div className="w-[50px] h-[50px]">
            <img src={coinsmall} className="w-full" alt="coin" />
          </div>
          <h1 className="text-[#fff] text-[42px] font-extrabold">
            {formattedCount}
          </h1>
        </div>
        <div className="w-full ml-[6px] flex space-x-1 items-center justify-center">
          <img
            src={bronze}
            className="w-[30px] h-[30px] relative"
            alt="bronze"
          />
          <h2
            onClick={levelsAction}
            className="text-[#9d99a9] text-[20px] font-medium"
          >
            {currentLevel.name}
          </h2>
          <MdOutlineKeyboardArrowRight className="w-[20px] h-[20px] text-[#9d99a9] mt-[2px]" />
        </div>
        <div className="w-full flex justify-center items-center pt-14 pb-36">
          <div className="w-[265px] h-[265px] relative">
            <div className="bg-[#efc26999] blur-[50px] absolute rotate-[35deg] w-[400px] h-[160px] -left-40 rounded-full"></div>
            <div className="image-container">
              <Container>
                <img
                  onPointerDown={handleClick}
                  ref={imageRef}
                  src={tapmecoin}
                  alt="Wobble"
                  className="wobble-image select-none"
                />
                {clicks.map((click) => (
                  <SlideUpText key={click.id} x={click.x} y={click.y}>
                    +{parseInt(level.slice(-1)) + 1}
                  </SlideUpText>
                ))}
              </Container>
            </div>
          </div>
        </div>
        <div className="flex flex-col space-y-6 fixed bottom-[120px] left-0 right-0 justify-center items-center px-5">
          <div className="flex flex-col w-full items-center justify-center">
            <div className="flex pb-[6px] space-x-1 items-center justify-center text-[#fff]">
              <img alt="flash" src={flash} className="w-[20px]" />
              <div className="">
                <span className="text-[18px] font-bold">
                  {displayEnergy}
                </span>
                <span className="text-[14px] font-medium">/ {maxEnergy}</span>
              </div>
            </div>
            <div className="flex w-full p-[4px] items-center bg-energybar rounded-[10px] border-[1px] border-borders2">
              <EnergyFill percentage={(energy / maxEnergy) * 100} />
            </div>
          </div>
        </div>
        {showLevels ? (
          <div className='fixed z-50 left-0 right-0 top-0 bottom-0 flex justify-center taskbg px-[16px] h-full'>
            <div className={`w-full flex flex-col items-center justify-start`}>
              <div className='flex w-full flex-col items-center text-center'>
                <h1 className={`${activeIndex === 0 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 1
                </h1>
                <h1 className={`${activeIndex === 1 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 2
                </h1>
                <h1 className={`${activeIndex === 2 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 3
                </h1>
                <h1 className={`${activeIndex === 3 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 4
                </h1>
                <h1 className={`${activeIndex === 4 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 5
                </h1>
                <h1 className={`${activeIndex === 5 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 6
                </h1>
                <h1 className={`${activeIndex === 6 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 7
                </h1>
                <h1 className={`${activeIndex === 7 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 8
                </h1>
                <p className='text-[#9a96a6] text-[14px] font-medium pt-1 pb-10 px-4'>
                  Your number of shares determines the league you enter:
                </p>
              </div>

              <div className='w-full flex justify-between items-center px-6'>
                <div className='flex items-center justify-center'>
                  <MdOutlineKeyboardArrowLeft onClick={() => setActiveIndex((prevIndex) => prevIndex - 1)} size={40} className={`${activeIndex === 0 ? 'opacity-0 pointer-events-none' : 'opacity-100 pointer-events-auto'} text-[#e8e8e8]`} />
                </div>
                <div className='flex flex-1 items-center justify-center'>
                  <img src={bronze} alt='bronze' className={`${activeIndex === 0 ? 'block' : 'hidden'} w-[200px]`} />
                  <img src={silver} alt='silver' className={`${activeIndex === 1 ? 'block' : 'hidden'} w-[200px] mt-[4px]`} />
                  <img src={gold} alt='gold' className={`${activeIndex === 2 ? 'block' : 'hidden'} w-[205px] mt-[5px]`} />
                  <img src={platinum} alt='platinum' className={`${activeIndex === 3 ? 'block' : 'hidden'} w-[200px]`} />
                  <img src={diamond} alt='diamond' className={`${activeIndex === 4 ? 'block' : 'hidden'} w-[200px]`} />
                </div>
                <div className='flex items-center justify-center'>
                  <MdOutlineKeyboardArrowRight onClick={() => setActiveIndex((prevIndex) => prevIndex + 1)} size={40} className={`${activeIndex === 7 ? 'opacity-0 pointer-events-none' : 'opacity-100 pointer-events-auto'} text-[#e8e8e8]`} />
                </div>
              </div>

              <div className='font-semibold text-[18px] pt-10 pb-5'>
                <span className={`${activeIndex === 0 ? 'block' : 'hidden'}`}> From 0</span>
                <span className={`${activeIndex === 1 ? 'block' : 'hidden'}`}> From 5k</span>
                <span className={`${activeIndex === 2 ? 'block' : 'hidden'}`}> From 25k</span>
                <span className={`${activeIndex === 3 ? 'block' : 'hidden'}`}> From 100k</span>
                <span className={`${activeIndex === 4 ? 'block' : 'hidden'}`}> From 1M</span>
                <span className={`${activeIndex === 5 ? 'block' : 'hidden'}`}> From 10M</span>
                <span className={`${activeIndex === 6 ? 'block' : 'hidden'}`}> From 50M</span>
                <span className={`${activeIndex === 7 ? 'block' : 'hidden'}`}> From 100M</span>
              </div>

              <div className={`${activeIndex === 0 ? 'block' : 'hidden'} w-full overflow-hidden`}>
                {nextLevel && count < nextLevel.minCount && (
                  <div className='flex w-full mt-2 p-[4px] items-center bg-energybar rounded-[10px] border-[1px] border-[#403f5c]'>
                    <div className='h-[8px] rounded-[8px] bg-btn' style={{ width: `${progress}%` }}></div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : null}
      </Animate>
    </>
  );
};

export default TapHome;
