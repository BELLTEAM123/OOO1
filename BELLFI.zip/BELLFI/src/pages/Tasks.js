import React, { useEffect, useState, useContext } from 'react';
import Animate from '../Components/Animate';
import { Outlet } from 'react-router-dom';
import { collection, query, where, getDocs, updateDoc, setDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { MdOutlineKeyboardArrowRight, MdOutlineKeyboardArrowLeft } from 'react-icons/md';
import { IoCheckmarkSharp } from "react-icons/io5";
import coinsmall from "../images/coinsmall.webp";
import bronze from "../images/bronz.png";
import silver from "../images/silver.png";
import gold from "../images/gold.png";
import platinum from "../images/platinum.png";
import diamond from "../images/diamond.png";
import taskbook from "../images/taskbook.webp";
import ref from "../images/ref.PNG";
import TaskOne from '../Components/TaskOne';
import TaskTwo from '../Components/TaskTwo';
import congrats from "../images/celebrate.gif";
import { EnergyContext } from '../context/EnergyContext';

const Tasks = () => {
  const levels = {
    level1: { name: 'Level 1', minCount: 0, nextLevel: 'level2', claimCount: 5000 },
    level2: { name: 'Level 2', minCount: 5000, nextLevel: 'level3', claimCount: 25000 },
    level3: { name: 'Level 3', minCount: 25000, nextLevel: 'level4', claimCount: 100000 },
    level4: { name: 'Level 4', minCount: 100000, nextLevel: 'level5', claimCount: 1000000 },
    level5: { name: 'Level 5', minCount: 1000000, nextLevel: 'level6', claimCount: 10000000 },
    level6: { name: 'Level 6', minCount: 10000000, nextLevel: 'level7', claimCount: 50000000 },
    level7: { name: 'Level 7', minCount: 50000000, nextLevel: 'level8', claimCount: 100000000 },
    level8: { name: 'Level 8', minCount: 100000000, nextLevel: null, claimCount: null },
  };

  const { count, setCount } = useContext(EnergyContext);
  const [level, setLevel] = useState('level1');
  const [showModal, setShowModal] = useState(false);
  const [showModal2, setShowModal2] = useState(false);
  const [claimLevel, setClaimLevel] = useState(false);
  const [showLevels, setShowLevels] = useState(false);
  const [taskCompleted, setTaskCompleted] = useState(false);
  const [taskCompleted2, setTaskCompleted2] = useState(false);
  const [activeIndex, setActiveIndex] = useState(1);
  const [referralCount, setReferralCount] = useState(0);
  const [taskOneCompleted, setTaskOneCompleted] = useState(false);
  const [taskTwoCompleted, setTaskTwoCompleted] = useState(false);
  const [loading, setLoading] = useState(true); // Loading state

  const handleMenu = (index) => setActiveIndex(index);

  useEffect(() => {
    const telegramUserid = window.Telegram.WebApp.initDataUnsafe?.user?.id;

    const fetchUserData = async () => {
      if (telegramUserid) {
        // Load user stats from local storage
        const localUserStats = JSON.parse(localStorage.getItem('userStatsTasks'));
        if (localUserStats && localUserStats.userid === telegramUserid) {
          setCount(localUserStats.count);
          setLevel(localUserStats.level || 'level1');
          setLoading(false); // Data loaded from local storage
        }

        // Fetch user stats from Firestore
        const userRef = collection(db, 'telegramUsers');
        const q = query(userRef, where('userId', '==', telegramUserid));
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
          const data = doc.data();
          setCount(data.count);
          setLevel(data.level || 'level1');

          // Save the latest user stats to local storage
          localStorage.setItem('userStatsTasks', JSON.stringify({
            userid: telegramUserid,
            count: data.count,
            level: data.level
          }));
        });

        setLoading(false); // Data loaded from Firestore
      }
    };

    const fetchReferralCount = async (userId) => {
      try {
        const userRef = collection(db, 'telegramUsers');
        const querySnapshot = await getDocs(userRef);
        let referralCount = 0;

        querySnapshot.forEach((doc) => {
          const data = doc.data();
          if (data.refereeId?.toString() === userId?.toString()) {
            referralCount += 1;
          }
        });

        setReferralCount(referralCount);
        console.log('Referral Count:', referralCount);
      } catch (error) {
        console.error('Error fetching referral count: ', error);
      }
    };

    const checkTaskCompletion = async (userid, taskId) => {
      try {
        const taskRef = collection(db, 'taskCompletions');
        const q = query(taskRef, where('userId', '==', userid), where('taskId', '==', taskId));
        const querySnapshot = await getDocs(q);
        return !querySnapshot.empty;
      } catch (error) {
        console.error("Error checking task completion: ", error);
        return false;
      }
    };

    fetchUserData();
    fetchReferralCount(telegramUserid);
    checkTaskCompletion(telegramUserid, 'referralTask50').then(completed => setTaskOneCompleted(completed));
    checkTaskCompletion(telegramUserid, 'referralTask100').then(completed => setTaskTwoCompleted(completed));
  }, []);

  const claimLevelHandler = async () => {
    const nextLevel = levels[level].nextLevel;
    if (nextLevel && count >= levels[nextLevel].minCount) {
      try {
        const userRef = collection(db, 'telegramUsers');
        const q = query(userRef, where('userId', '==', window.Telegram.WebApp.initDataUnsafe?.user?.id));
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
          updateDoc(doc.ref, {
            level: nextLevel
          });
        });
        setLevel(nextLevel);

        // Update local storage with new level
        const localUserStats = JSON.parse(localStorage.getItem('userStatsTasks'));
        if (localUserStats && localUserStats.userid === window.Telegram.WebApp.initDataUnsafe?.user?.id) {
          localUserStats.level = nextLevel;
          localStorage.setItem('userStatsTasks', JSON.stringify(localUserStats));
        }
      } catch (e) {
        console.error("Error updating document: ", e);
      }
    }
  };

  const saveTaskCompletionToFirestore = async (userid, taskId) => {
    try {
      const taskRef = collection(db, 'taskCompletions');
      const newTaskDoc = doc(taskRef, `${userid}_${taskId}`);
      await setDoc(newTaskDoc, { userId: userid, taskId: taskId });
      console.log("Task saved successfully:", taskId);
    } catch (error) {
      console.error("Error saving task completion: ", error);
    }
  };

  const claimReferralReward = async (points, taskId) => {
    try {
      const userId = window.Telegram.WebApp.initDataUnsafe?.user?.id;
      const userRef = collection(db, 'telegramUsers');
      const q = query(userRef, where('userId', '==', userId));
      const querySnapshot = await getDocs(q);
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        const newCount = data.count + points;
        updateDoc(doc.ref, {
          count: newCount
        });
        setCount(newCount);
        saveTaskCompletionToFirestore(userId, taskId);
        if (taskId === 'referralTask50') {
          setTaskOneCompleted(true);
        } else if (taskId === 'referralTask100') {
          setTaskTwoCompleted(true);
        }

        // Update local storage with new count
        const localUserStats = JSON.parse(localStorage.getItem('userStatsTasks'));
        if (localUserStats && localUserStats.userid === userId) {
          localUserStats.count = newCount;
          localStorage.setItem('userStatsTasks', JSON.stringify(localUserStats));
        }
      });
    } catch (error) {
      console.error('Error claiming referral reward: ', error);
    }
  };

  const currentLevel = levels[level];
  const nextLevel = currentLevel?.nextLevel ? levels[currentLevel.nextLevel] : null;
  const progress = nextLevel ? ((count - currentLevel.minCount) / (nextLevel.minCount - currentLevel.minCount)) * 100 : 100;
  const referralProgressTask50 = referralCount >= 50 ? 100 : (referralCount / 50 ) * 100;
  const referralProgressTask100 = referralCount >= 100 ? 100 : (referralCount / 100) * 100;

  if (loading) {
    return (
      <div className="loading-container">
        <h1></h1>
      </div>
    );
  }

  return (
    <>
      <Animate>
        <div className='w-full justify-center flex-col space-y-3 px-5'>
          <div className='fixed top-0 left-0 right-0 pt-8 px-5'>
            <div className="flex space-x-2 justify-center items-center relative">
              <div id="congrat" className='opacity-0 invisible w-[80%] absolute pl-10 ease-in-out duration-500 transition-all'>
                <img src={congrats} alt="congrats" className="w-full"/>
              </div>
              <div className="w-[50px] h-[50px]">
                <img src={coinsmall} className="w-full" alt="coin"/>
              </div>
              <h1 className="text-[#fff] text-[42px] font-extrabold">
                {new Intl.NumberFormat().format(count).replace(/,/g, " ")}
              </h1>
            </div>
            <div onClick={() => setShowLevels(true)} className="w-full flex ml-[6px] space-x-1 items-center justify-center">
              <img src={bronze} className="w-[30px] h-[30px] relative" alt="bronze" />
              <h2 className="text-[#9d99a9] text-[20px] font-medium">
                {currentLevel.name}
              </h2>
              <MdOutlineKeyboardArrowRight className="w-[20px] h-[20px] text-[#9d99a9] mt-[2px]" />
            </div>
            <div className='bg-borders w-full px-5 h-[1px] !mt-5 !mb-5'></div>
            <div className='w-full border-[1px] border-borders rounded-[10px] p-1 flex items-center'>
              <div onClick={() => handleMenu(1)} className={`${activeIndex === 1 ? 'bg-cards' : ''}  rounded-[6px] py-[12px] px-3 w-[33%] flex justify-center text-center items-center`}>
                Special
              </div>
              <div onClick={() => handleMenu(2)} className={`${activeIndex === 2 ? 'bg-cards' : ''}  rounded-[6px] py-[12px] px-3 w-[33%] flex justify-center text-center items-center`}>
                Levels
              </div>
              <div onClick={() => handleMenu(3)} className={`${activeIndex === 3 ? 'bg-cards' : ''}  rounded-[6px] py-[12px] px-3 w-[33%] flex justify-center text-center items-center`}>
                Ref Tasks
              </div>
            </div>
            <div className='bg-[#efc26999] blur-[50px] absolute rotate-[35deg] w-[400px] h-[160px] -left-40 rounded-full'></div>
          </div>

          <div className='!mt-[204px] w-full h-[60vh] flex flex-col'>
            <div className={`${activeIndex === 1 ? 'flex' : 'hidden'} alltaskscontainer flex-col w-full space-y-2`}>
              <div onClick={() => setShowModal(true)} className='bg-cards rounded-[10px] p-[14px] flex justify-between items-center'>
                <div className='flex flex-1 items-center space-x-2'>
                  <div className=''>
                    <img src={taskbook} alt="tasks" className='w-[50px]'/>
                  </div>
                  <div className='flex flex-col space-y-1'>
                    <span className='font-semibold'>
                      Join Our Telegram Community
                    </span>
                    <div className='flex items-center space-x-1'>
                      <span className="w-[20px] h-[20px]">
                        <img src={coinsmall} className="w-full" alt="coin"/>
                      </span>
                      <span className='font-medium'>
                        10000
                      </span>
                    </div>
                  </div>
                </div>
                <div className=''>
                  {taskCompleted ? (
                    <IoCheckmarkSharp className="w-[20px] h-[20px] text-[#5bd173] mt-[2px]"/>
                  ) : (
                    <MdOutlineKeyboardArrowRight className="w-[20px] h-[20px] text-[#e0e0e0] mt-[2px]"/>
                  )}
                </div>
              </div>
            </div>

            <div className={`${activeIndex === 2 ? 'flex' : 'hidden'} alltaskscontainer flex-col w-full space-y-2`}>
              <div className='bg-cards rounded-[10px] p-[14px] flex flex-wrap justify-between items-center'>
                <div className='flex flex-1 items-center space-x-2'>
                  <div className=''>
                    <img src={bronze} alt="bronze" className='w-[55px]'/>
                  </div>
                  <div className='flex flex-col space-y-1'>
                    <span className='font-semibold'>
                      {currentLevel.name}
                    </span>
                    <div className='flex items-center space-x-1'>
                      <span className="w-[20px] h-[20px]">
                        <img src={coinsmall} className="w-full" alt="coin"/>
                      </span>
                      <span className='font-medium'>
                        {nextLevel ? nextLevel.minCount : "Max Level"}
                      </span>
                    </div>
                  </div>
                </div>
                <div className=''>
                  {nextLevel && count < nextLevel.minCount && (
                    <span className='bg-btn2 rounded-[8px] font-semibold py-2 px-3 text-[#fff6]'>
                      Upgrade Level
                    </span>
                  )}
                  {nextLevel && count >= nextLevel.minCount && (
                    <button onClick={claimLevelHandler} className='bg-btn relative rounded-[8px] font-semibold py-2 px-3 text-[#fff]'>
                      Claim
                    </button>
                  )}
                </div>
                <div className='flex w-full mt-2 p-[4px] items-center bg-energybar rounded-[10px] border-[1px] border-borders'>
                  <div className='h-[8px] rounded-[8px] bg-btn' style={{ width: `${progress}%` }}></div>
                </div>
              </div>
            </div>

            <div className={`${activeIndex === 3 ? 'flex' : 'hidden'} alltaskscontainer flex-col w-full space-y-2`}>
              <div className='bg-cards rounded-[10px] p-[14px] flex flex-wrap justify-between items-center'>
                <div className='flex flex-1 items-center space-x-2'>
                  <div className=''>
                    <img src={ref} alt="ref" className='w-[55px]'/>
                  </div>
                  <div className='flex flex-col space-y-1'>
                    <span className='font-semibold'>
                      Invite 50 Friends
                    </span>
                    <div className='flex items-center space-x-1'>
                      <span className="w-[20px] h-[20px]">
                        <img src={coinsmall} className="w-full" alt="coin"/>
                      </span>
                      <span className='font-medium'>
                        200000
                      </span>
                    </div>
                  </div>
                </div>
                <div className=''>
                  {referralCount >= 50 && !taskOneCompleted && (
                    <button
                      onClick={() => {
                        claimReferralReward(200000, 'referralTask50');
                        setTaskOneCompleted(true);  // Set task completion state to true
                      }}
                      className='bg-btn relative rounded-[8px] font-semibold py-2 px-3 text-[#fff]'
                    >
                      Claim
                    </button>
                  )}
                  {referralCount < 50 && (
                    <span className='bg-btn2 rounded-[8px] font-semibold py-2 px-3 text-[#fff6]'>
                      Invite More
                    </span>
                  )}
                  {taskOneCompleted && (
                    <button className='bg-btn relative rounded-[8px] font-semibold py-2 px-3 text-[#fff]'>
                      Task Completed
                    </button>
                  )}
                </div>
                <div className='flex w-full mt-2 p-[4px] items-center bg-energybar rounded-[10px] border-[1px] border-borders'>
                  <div className='h-[8px] rounded-[8px] bg-btn' style={{ width: `${referralProgressTask50}%` }}></div>
                </div>
              </div>
              <div className='bg-cards rounded-[10px] p-[14px] flex flex-wrap justify-between items-center'>
                <div className='flex flex-1 items-center space-x-2'>
                  <div className=''>
                    <img src={ref} alt="ref" className='w-[55px]'/>
                  </div>
                  <div className='flex flex-col space-y-1'>
                    <span className='font-semibold'>
                      Invite 100 Friends
                    </span>
                    <div className='flex items-center space-x-1'>
                      <span className="w-[20px] h-[20px]">
                        <img src={coinsmall} className="w-full" alt="coin"/>
                      </span>
                      <span className='font-medium'>
                        500000
                      </span>
                    </div>
                  </div>
                </div>
                <div className=''>
                  {referralCount >= 100 && !taskTwoCompleted && (
                    <button
                      onClick={() => {
                        claimReferralReward(500000, 'referralTask100');
                        setTaskTwoCompleted(true);  // Set task completion state to true
                      }}
                      className='bg-btn relative rounded-[8px] font-semibold py-2 px-3 text-[#fff]'
                    >
                      Claim
                    </button>
                  )}
                  {referralCount < 100 && (
                    <span className='bg-btn2 rounded-[8px] font-semibold py-2 px-3 text-[#fff6]'>
                      Invite More
                    </span>
                  )}
                  {taskTwoCompleted && (
                    <button className='bg-btn relative rounded-[8px] font-semibold py-2 px-3 text-[#fff]'>
                      Task Completed
                    </button>
                  )}
                </div>
                <div className='flex w-full mt-2 p-[4px] items-center bg-energybar rounded-[10px] border-[1px] border-borders'>
                  <div className='h-[8px] rounded-[8px] bg-btn' style={{ width: `${referralProgressTask100}%` }}></div>
                </div>
              </div>
            </div>
          </div>

          <TaskOne showModal={showModal} setShowModal={setShowModal} />
          <TaskTwo showModal2={showModal2} setShowModal2={setShowModal2} />
        </div>
        <Outlet />
        {showLevels ? (
          <div className='fixed z-50 left-0 right-0 top-0 bottom-0 flex justify-center taskbg px-[16px] h-full'>
            <div className={`w-full flex flex-col items-center justify-start`}>
              <div className='flex w-full flex-col items-center text-center'>
                <h1 className={`${activeIndex === 0 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 1
                </h1>
                <h1 className={`${activeIndex === 1 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 2
                </h1>
                <h1 className={`${activeIndex === 2 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 3
                </h1>
                <h1 className={`${activeIndex === 3 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 4
                </h1>
                <h1 className={`${activeIndex === 4 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 5
                </h1>
                <h1 className={`${activeIndex === 5 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 6
                </h1>
                <h1 className={`${activeIndex === 6 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 7
                </h1>
                <h1 className={`${activeIndex === 7 ? 'block' : 'hidden'} text-[20px] font-semibold`}>
                  Level 8
                </h1>
                <p className='text-[#9a96a6] text-[14px] font-medium pt-1 pb-10 px-4'>
                  Your number of shares determines the league you enter:
                </p>
              </div>

              <div className='w-full flex justify-between items-center px-6'>
                <div className='flex items-center justify-center'>
                  <MdOutlineKeyboardArrowLeft onClick={() => setActiveIndex((prevIndex) => prevIndex - 1)} size={40} className={`${activeIndex === 0 ? 'opacity-0 pointer-events-none' : 'opacity-100 pointer-events-auto'} text-[#e8e8e8]`} />
                </div>
                <div className='flex flex-1 items-center justify-center'>
                  <img src={bronze} alt='bronze' className={`${activeIndex === 0 ? 'block' : 'hidden'} w-[200px]`} />
                  <img src={silver} alt='silver' className={`${activeIndex === 1 ? 'block' : 'hidden'} w-[200px] mt-[4px]`} />
                  <img src={gold} alt='gold' className={`${activeIndex === 2 ? 'block' : 'hidden'} w-[205px] mt-[5px]`} />
                  <img src={platinum} alt='platinum' className={`${activeIndex === 3 ? 'block' : 'hidden'} w-[200px]`} />
                  <img src={diamond} alt='diamond' className={`${activeIndex === 4 ? 'block' : 'hidden'} w-[200px]`} />
                </div>
                <div className='flex items-center justify-center'>
                  <MdOutlineKeyboardArrowRight onClick={() => setActiveIndex((prevIndex) => prevIndex + 1)} size={40} className={`${activeIndex === 7 ? 'opacity-0 pointer-events-none' : 'opacity-100 pointer-events-auto'} text-[#e8e8e8]`} />
                </div>
              </div>

              <div className='font-semibold text-[18px] pt-10 pb-5'>
                <span className={`${activeIndex === 0 ? 'block' : 'hidden'}`}> From 0</span>
                <span className={`${activeIndex === 1 ? 'block' : 'hidden'}`}> From 5k</span>
                <span className={`${activeIndex === 2 ? 'block' : 'hidden'}`}> From 25k</span>
                <span className={`${activeIndex === 3 ? 'block' : 'hidden'}`}> From 100k</span>
                <span className={`${activeIndex === 4 ? 'block' : 'hidden'}`}> From 1M</span>
                <span className={`${activeIndex === 5 ? 'block' : 'hidden'}`}> From 10M</span>
                <span className={`${activeIndex === 6 ? 'block' : 'hidden'}`}> From 50M</span>
                <span className={`${activeIndex === 7 ? 'block' : 'hidden'}`}> From 100M</span>
              </div>

              <div className={`${activeIndex === 0 ? 'block' : 'hidden'} w-full overflow-hidden`}>
                {nextLevel && count < nextLevel.minCount && (
                  <div className='flex w-full mt-2 p-[4px] items-center bg-energybar rounded-[10px] border-[1px] border-[#403f5c]'>
                    <div className='h-[8px] rounded-[8px] bg-btn' style={{ width: `${progress}%` }}></div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : null}
      </Animate>
    </>
  );
}

export default Tasks;
