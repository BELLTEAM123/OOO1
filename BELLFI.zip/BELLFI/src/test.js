import { doc, setDoc, updateDoc, getDoc } from "./firebase";
import { db } from './firebase'; // Make sure to import your Firestore configuration

// Define the function to save task completion with default values
const saveTaskCompletionToFirestore = async (userid, taskId, completed) => {
  try {
    const taskRef = doc(db, "taskCompletions", userid);
    const taskDoc = await getDoc(taskRef);

    if (taskDoc.exists()) {
      const taskData = taskDoc.data();
      const completedTasks = Array.isArray(taskData.completedTasks) ? taskData.completedTasks : [];

      if (completed) {
        // Add taskId to completedTasks if not already present
        if (!completedTasks.includes(taskId)) {
          completedTasks.push(taskId);
        }
      } else {
        // Remove taskId from completedTasks if present
        const index = completedTasks.indexOf(taskId);
        if (index > -1) {
          completedTasks.splice(index, 1);
        }
      }

      await updateDoc(taskRef, { completedTasks });
    } else {
      // Create document with completedTasks if it doesn't exist
      await setDoc(taskRef, {
        completedTasks: completed ? [taskId] : []
      });
    }
    console.log(`Task completion saved successfully for user: ${userid}, taskId: ${taskId}, completed: ${completed}`);
  } catch (error) {
    console.error("Error saving task completion: ", error);
  }
};

// Test function with default values
const testSaveTaskCompletion = async () => {
  const testUserId = 'testUser123';  // Default user ID for testing
  const testTaskId = 'testTask456';  // Default task ID for testing
  const testCompleted = true;        // Default completion status for testing

  await saveTaskCompletionToFirestore(testUserId, testTaskId, testCompleted);

  // Optionally: Check Firestore to see if the document has been created/updated as expected
};

// Run the test
testSaveTaskCompletion();
